package com.example.term_project_9;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class joinRoomListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_room_list);
    }
}
