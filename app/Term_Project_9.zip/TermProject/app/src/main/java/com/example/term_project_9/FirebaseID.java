package com.example.term_project_9;

public class FirebaseID {
    public static String documentId = "documentId";
    public static String email = "email";
    public static String password = "password";
    public static String user = "user";
}
